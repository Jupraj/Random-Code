package singh.bcs345.hwk.vet.business;


import java.io.PrintStream;
import java.util.Scanner;
/**
 * This is the Pet class
 * Contains the Name, Species and Gender variables
 * Getters/Setters
 * Default constructor and a constructor with three parameters
 * A Write and Read function
 * A JSON formatting function and a toString formatting function
 * @author Jupraj Singh
 * @version 1.00
 * @since 10/3/2018
 *
 */
public class Pet {
	// member variables
	private String Name;
	private String Species;
	private String Gender;
	//Default constructor
	public Pet()
	{
		Name = "Default Name";
		Species = "Dog";
		Gender = "Male";
	}
	//constructor that takes three parameters
	public Pet(String Na,String S,String G)
	{
		Name = Na;
		Species = S;
		Gender = G;
	}
	//Getters
	public String getName()
	{
		return Name;
	}
	public String getSpecies()
	{
		return Species;
	}
	public String getGender()
	{
		return Gender;
	}
	//Setters
	public void setName(String N)
	{
		Name = N;
	}
	public void setSpecies(String S)
	{
		Species = S;
	}
	public void setGender(String G)
	{
		Gender = G;
	}
	//Read from scanner
	public void Read(Scanner s)
	{
		Name = s.nextLine();
		Species = s.nextLine();
		Gender = s.nextLine();
	}
	//Write to a printStream file
	public void Write(PrintStream ps)
	{
		ps.printf("%s\n%s\n%s",Name,Species,Gender);
	}
	//returns a string using JSON formatting
	public String GetJSON()
	{
		return "{" + "\"Name\""+ ":" + Name + "," + "\"Species\"" + ":" + Species + ":" + "\"Gender\"" + ":" + Gender + "}";
	}
	//returns a string that contains the value of the member variables with descriptive text
	@Override
	public String toString()
	{
		return "Name:" + Name + "\nSpecies:" + Species + "\nGender:" + Gender;
	}
}
