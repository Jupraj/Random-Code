package singh.bcs345.hwk.vet.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 *This is an appointment class which will contain the date of an appointment and the Pet information
 * @author Jupraj Singh
 * @since 10-24-2018
 * 
 *
 */
public class Appointment {
	// member variables
	int Month;
	int Day;
	int Year;
	Pet Pet;
	
	/**
	 *  default constructor which will assign default values to member variables
	 */
	public Appointment()
	{
		Month = 3;
		Day = 16;
		Year = 1998;
		Pet = new Pet("Pluto", "Dog", "Male");
	}
	/** 
	 * Getters which will return the value of a member variable
	 * @return
	 */
	public int getMonth()
	{
		return Month;
	}
	public int getDay()
	{
		return Day;
	}
	public int getYear()
	{
		return Year;
	}
	public Pet getPet()
	{
		return Pet;
	}
	/** 
	 * Setters which will allow users to set the values of a member variable
	 * @param m
	 */
	public void setMonth(int m)
	{
		Month = m;
	}
	public void setDay(int d)
	{
		Day = d;
	}
	public void setYear(int y)
	{
		Year = y;
	}
	public void setPet(Pet p)
	{
		Pet = p;
	}
	/**
	 * A  Write function Which will write out the values of the member variables without any additional text
	 * @param ps
	 */
	public void Write(PrintStream ps)
	{
		ps.printf("%d\n%d\n%d\n", Month, Day, Year);
		ps.printf("%s\n%s\n%s\n", Pet.getName(),Pet.getSpecies(), Pet.getGender());
	}
	/**
	 * A Read function which will read the member variables from a scanner
	 * @param s
	 */
	public void Read(Scanner s)
	{
		
		Month = Integer.parseInt(s.nextLine());
		Day = Integer.parseInt(s.nextLine());
		Year = Integer.parseInt(s.nextLine());
		Pet.Read(s);
		
	}
	/**
	 * Returns a string with JSON formatting for the member variables
	 * @return
	 */
	public String GetJSON()
	{
			return "{\n" + "\t\"month\" : " + Month + ",\n"
			+ "\t\"day\" : " + Day + ",\n"
			+ "\t\"year\" : " + Year + ","
			+ "\n\t\"pet\" : " + "\n\t{" 
			+ "\n\t\t\"name\" : \"" + Pet.getName() + "\","
			+ "\n\t\t\"species\" : \"" + Pet.getSpecies() + "\","
			+ "\n\t\t\"gender\" : \"" + Pet.getGender() + "\"\n\t}" + "\n}";
	}
	/** 
	 * a toString method which will return a string with formatting of the member variables
	 */
	@Override
	public String toString()
	{
		return "Date: " + Month + "/" + Day + "/" + Year
		+ "\nName: " + Pet.getName()
		+ "\nSpecies: " + Pet.getSpecies()
		+ "\nGender: " + Pet.getGender();
	}
	
	
	
	
	
	
	
}
