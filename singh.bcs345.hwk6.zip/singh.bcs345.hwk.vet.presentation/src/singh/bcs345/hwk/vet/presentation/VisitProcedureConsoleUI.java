package singh.bcs345.hwk.vet.presentation;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

import singh.bcs345.hwk.vet.business.VisitProcedure;

/**
 * This method will create a UI which will allow users
 * to read visit procedure from file,
 *  write visit procedure from file,
 *   show visit procedure data with descriptive text on screen
 *   show visit procedure JSON on screen
 *  and exit
 * @author Jupraj Singh
 * @since 10/25/2018
 *
 */
public class VisitProcedureConsoleUI {
	
	 /**
	  * This method shows the UI and gives users the option to select a choice
	  */
	public void ShowUI()
	{
		System.out.println("Visit Procedure UI"
				       + "\n-------------------"
				       +  "\n1 - Read visit procedure procedure from file"
				       +  "\n2- Write visit procedure to file"
				       +  "\n3- Show visit procedure data with descriptive text on screen"
				       +   "\n4- Show visit procedure JSON on screen"
				       +   "\n5- Exit"
				       +   "\nEnter Choice: ");
		
		Scanner inputScanner;
		inputScanner = new Scanner(System.in);
		int userChoice;
		userChoice = inputScanner.nextInt();
		VisitProcedure v = new VisitProcedure();
		PrintStream ps = null;
		
		/**
		 * switch cases which do different things depending on what the user chooses
		 */
		while (userChoice != 5)
		{
		switch(userChoice)
		{
		// Reads visit procedure's data
		case 1:
			System.out.println("Enter the name of the file: " );
			try
			{	
				String file;
				file = inputScanner.next();
				Scanner scanner = new Scanner(new FileReader(file));
				v.Read(scanner);
				System.out.println("Reading is done, enter a new choice: ");
				userChoice = inputScanner.nextInt();
				
				break;
			}
			catch (FileNotFoundException f)
			{
				System.out.println("Error in finding file");
			}
			catch (NullPointerException n)
			{
				System.out.println(" Null pointer exception");
			}
			
			catch (Exception e)
			{
				System.out.println(" general exception");
			}
			
		case 2:
			// Write data from the Visit Procedure instance to file
			System.out.println("Please enter a file name to write: ");
			String out;
			
			try
			{
				out = inputScanner.next();
				ps = new PrintStream(out);
				v.Write(ps);
				System.out.println("Writing is done, enter a new choice: ");
				userChoice = inputScanner.nextInt();
			}
			catch (FileNotFoundException f)
			{
				System.out.println("File not found");
			}
			catch (NullPointerException n)
			{
				System.out.println("Null pointer");
			}
			catch (Exception e)
			{
				System.out.println("general exception");
			}
			break;
			
		case 3:
			System.out.println(v.toString());
			System.out.println("to string is done, enter a new choice: ");
			userChoice = inputScanner.nextInt();
			break;
		case 4:
			System.out.println(v.getJSON());
			System.out.println("JSON is done, enter a new choice: ");
			userChoice = inputScanner.nextInt();
		
		case 5:
			System.out.println("Program is closing...");
			break;
		default:
			System.out.println("This is not a choice, please enter a valid choice: ");
			userChoice = inputScanner.nextInt();
		}
		}
		
		
	}
	
}
