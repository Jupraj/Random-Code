package singh.bcs345.hwk.vet.presentation;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.InputMismatchException;
import java.util.Scanner;

import singh.bcs345.hwk.vet.business.Visit;
import singh.bcs345.hwk.vet.business.VisitProcedure;

/**
 * This is the Visit UI class
 * This will present a menu to the user and perform an action depending on what the user chooses to do
 * The choices the user gets are:
 * 1- reading visit info from file
 * 2- Writing visit info to a file
 * 3- Showing a visit procedure by index
 * 4- showing the visit procedure with highest amount due
 * 5- showing the visit report on screen
 * 6- SHowing the visit as a JSON string on screen
 * 7- Show visit toString on screen
 * 8- Exiting the menu\
 * @since 11/14/2018
 * @author Jupraj Singh
 *
 */
public class VisitConsoleUI {
	/**
	 * This method will present users with a menu 
	 */
	public void ShowUI()
	{
		//Scanner inputScanner;
		//inputScanner = new Scanner(System.in);
		//int userChoice;
		//userChoice = inputScanner.nextInt();
		//VisitProcedure v = new VisitProcedure();
		//PrintStream ps = null;
		
		Visit v= new Visit();
		PrintStream ps = null;
		int choice;
		
		Scanner s = new Scanner(System.in);
		System.out.println("Choose UI");
		System.out.println("---------");
		System.out.println("1 - Read visit info from file");
		System.out.println("2 - Write visit info to file");
		System.out.println("3 - Show visit procedure by index");
		System.out.println("4 - Show visit procedure with highest amount due");
		System.out.println("5 - Show visit report on screen");
		System.out.println("6 - Show visit as JSON string on screen");
		System.out.println("7 - Show visit toString on screen");
		System.out.println("8 - Exit");
		System.out.println("Enter choice:");
		choice = s.nextInt();
	
		while (choice !=8){

		switch (choice)
		{
		
		case 1: 
			System.out.println("Enter File to read from:");
			String File = s.next();
			try
			{
				Scanner input = new Scanner (new FileReader(File));
				v.Read(input);
				System.out.println("Enter new choice:");
				System.out.println("Choose UI");
				System.out.println("---------");
				System.out.println("1 - Read visit info from file");
				System.out.println("2 - Write visit info to file");
				System.out.println("3 - Show visit procedure by index");
				System.out.println("4 - Show visit procedure with highest amount due");
				System.out.println("5 - Show visit report on screen");
				System.out.println("6 - Show visit as JSON string on screen");
				System.out.println("7 - Show visit toString on screen");
				System.out.println("8 - Exit");
				System.out.println("Enter choice:");
				choice = s.nextInt();
			
				
			}
			catch(FileNotFoundException f)
			{
				System.out.println("File not found");
			}


			catch (NullPointerException n)
			{
				System.out.println("Null Pointer");
			}
			
			break;
			
		case 2:
			
			try 
			{
				System.out.println("Please enter a file name to write to: ");
				String OutFile;
				OutFile = s.next();
			ps = new PrintStream(OutFile);
			v.Write(ps);
			System.out.println("Writing is done, enter a new choice: ");
			System.out.println("Choose UI");
			System.out.println("---------");
			System.out.println("1 - Read visit info from file");
			System.out.println("2 - Write visit info to file");
			System.out.println("3 - Show visit procedure by index");
			System.out.println("4 - Show visit procedure with highest amount due");
			System.out.println("5 - Show visit report on screen");
			System.out.println("6 - Show visit as JSON string on screen");
			System.out.println("7 - Show visit toString on screen");
			System.out.println("8 - Exit");
			System.out.println("Enter choice:");
			choice = s.nextInt();
			
			}
			catch (FileNotFoundException f)
			{
				System.out.println("File not found");
			}
			catch (NullPointerException n)
			{
				n.printStackTrace();
				System.out.println("Null pointer");
			}
			catch (Exception ex)
			{
				System.out.println("general exception");
			}
			break;
		case 3:
			System.out.println("Enter an index of a visitProcedure: ");
			
			{
				try {
					int index = s.nextInt();
					v.GetByIndex(index);
					System.out.print(v.GetByIndex(index));
					System.out.println("\nEnter a new choice:");
					System.out.println("Choose UI");
					System.out.println("---------");
					System.out.println("1 - Read visit info from file");
					System.out.println("2 - Write visit info to file");
					System.out.println("3 - Show visit procedure by index");
					System.out.println("4 - Show visit procedure with highest amount due");
					System.out.println("5 - Show visit report on screen");
					System.out.println("6 - Show visit as JSON string on screen");
					System.out.println("7 - Show visit toString on screen");
					System.out.println("8 - Exit");
					System.out.println("Enter choice:");
					choice = s.nextInt();
				}
				catch (NullPointerException n)
				{
					System.err.println("Null Pointer");
				}
				catch ( ArrayIndexOutOfBoundsException e)
				{
					System.err.println("Index out of bounds");
				}
			}
			
			break;
		case 4: 
			System.out.println(v.GetHighestProcedureAmountDue());
			System.out.println("\nEnter a new choice:");
			System.out.println("Choose UI");
			System.out.println("---------");
			System.out.println("1 - Read visit info from file");
			System.out.println("2 - Write visit info to file");
			System.out.println("3 - Show visit procedure by index");
			System.out.println("4 - Show visit procedure with highest amount due");
			System.out.println("5 - Show visit report on screen");
			System.out.println("6 - Show visit as JSON string on screen");
			System.out.println("7 - Show visit toString on screen");
			System.out.println("8 - Exit");
			System.out.println("Enter choice:");
			choice = s.nextInt();
			
			
			break;
		case 5:
			
			
			try
			{
				
				ps = new PrintStream(System.out);
				v.Report(ps);
				System.out.println("\nReport is done, enter new choice: ");
				System.out.println("Choose UI");
				System.out.println("---------");
				System.out.println("1 - Read visit info from file");
				System.out.println("2 - Write visit info to file");
				System.out.println("3 - Show visit procedure by index");
				System.out.println("4 - Show visit procedure with highest amount due");
				System.out.println("5 - Show visit report on screen");
				System.out.println("6 - Show visit as JSON string on screen");
				System.out.println("7 - Show visit toString on screen");
				System.out.println("8 - Exit");
				System.out.println("Enter choice:");
				choice = s.nextInt();
			}

			catch (NullPointerException n)
			{
				System.out.println("Null pointer");
			}
			catch (Exception e)
			{
				System.out.println("general exception");
			}
			break;
		case 6:
			System.out.println(v.GetJSON());
			System.out.println("JSON is done, enter a new choice: ");
			System.out.println("Choose UI");
			System.out.println("---------");
			System.out.println("1 - Read visit info from file");
			System.out.println("2 - Write visit info to file");
			System.out.println("3 - Show visit procedure by index");
			System.out.println("4 - Show visit procedure with highest amount due");
			System.out.println("5 - Show visit report on screen");
			System.out.println("6 - Show visit as JSON string on screen");
			System.out.println("7 - Show visit toString on screen");
			System.out.println("8 - Exit");
			System.out.println("Enter choice:");
			choice = s.nextInt();
		
			break;
		case 7:
			System.out.println(v.toString());
			System.out.println("toString is done, enter a new choice: ");
			System.out.println("Choose UI");
			System.out.println("---------");
			System.out.println("1 - Read visit info from file");
			System.out.println("2 - Write visit info to file");
			System.out.println("3 - Show visit procedure by index");
			System.out.println("4 - Show visit procedure with highest amount due");
			System.out.println("5 - Show visit report on screen");
			System.out.println("6 - Show visit as JSON string on screen");
			System.out.println("7 - Show visit toString on screen");
			System.out.println("8 - Exit");
			choice = s.nextInt();
		
			System.out.println("Enter choice:");
			break;
		default:
			System.out.println("This is not a choice, please enter a valid choice: ");
			System.out.println("Choose UI");
			System.out.println("---------");
			System.out.println("1 - Read visit info from file");
			System.out.println("2 - Write visit info to file");
			System.out.println("3 - Show visit procedure by index");
			System.out.println("4 - Show visit procedure with highest amount due");
			System.out.println("5 - Show visit report on screen");
			System.out.println("6 - Show visit as JSON string on screen");
			System.out.println("7 - Show visit toString on screen");
			System.out.println("8 - Exit");
			System.out.println("Enter choice:");
			choice = s.nextInt();
		
			
		}
		}
		
		
		
	}
}
