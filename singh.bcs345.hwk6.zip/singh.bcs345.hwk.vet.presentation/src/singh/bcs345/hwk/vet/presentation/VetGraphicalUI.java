package singh.bcs345.hwk.vet.presentation;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 * This is the VetGraphicalUI class
 * Which will have the ShowUI function which will be used to display the GUI
 * if a user chooses it in the main
 * @author Jupraj Singh
 * @since 12/12/2018
 *
 */
public class VetGraphicalUI{
	public void ShowUI() {
		Application.launch(VetApplication.class);
	}


	
	
}

