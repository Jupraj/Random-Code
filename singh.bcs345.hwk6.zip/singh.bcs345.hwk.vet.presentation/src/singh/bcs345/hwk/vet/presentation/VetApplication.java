package singh.bcs345.hwk.vet.presentation;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import singh.bcs345.hwk.vet.business.*;

public class VetApplication extends Application{
	private Visit Visit = new Visit();
	// Labels for OverView Tab
	private Label m_VetNameLabel;
	private Label m_PetNameLabel;
	private Label m_PetSpeciesLabel;
	private Label m_PetGenderLabel;
	private Label m_ProcedureAmountLabel;
	private Label m_ProcedureAmountCoveredLabel;
	private Label m_ProcedureAmountDueLabel;
	// TEXT AREAS for OverView Tab
	private TextArea m_VetNameTextArea;
	private TextArea m_PetNameTextArea;
	private TextArea m_PetSpeciesTextArea;
	private TextArea m_PetGenderTextArea;
	private TextArea m_TotalProcedureAmountTextArea;
	private TextArea m_TotalProcedureAmountCoveredTextArea;
	private TextArea m_TotalProcedureAmountDueTextArea;
	


	@Override
	public void start(Stage primaryStage) {
		
		BorderPane border = new BorderPane();
		TabPane tabPane = new TabPane();
		MenuBar menuBar = new MenuBar();
		Menu fileMenu = new Menu("File");
		menuBar.getMenus().add(fileMenu);
		
		// CREATING MENU ITEMS
		MenuItem open = new MenuItem("Open");
		MenuItem saveAs = new MenuItem("Save As...");
		MenuItem saveReport = new MenuItem("Save Report...");
		MenuItem exportAsJSON = new MenuItem("Export As JSON...");
		MenuItem exit = new MenuItem("Exit");
		//Making separators
		SeparatorMenuItem  sep = new SeparatorMenuItem();
		SeparatorMenuItem  sep2 = new SeparatorMenuItem();
		SeparatorMenuItem  sep3 = new SeparatorMenuItem();
		// Adding items to menu
		fileMenu.getItems().add(open);
		fileMenu.getItems().add(sep);
		fileMenu.getItems().add(saveAs);
		fileMenu.getItems().add(saveReport);
		fileMenu.getItems().add(sep2);
		fileMenu.getItems().add(exportAsJSON);
		fileMenu.getItems().add(sep3);
		fileMenu.getItems().add(exit);
		
		
		
		
		// Setting OverView Tab
		Tab overviewTab = new Tab();
		overviewTab.setText("Overview");
		// Setting Visit Procedure Data tab
		Tab visitProcedureDataTab = new Tab();
		visitProcedureDataTab.setText("Visit Procedure Data");

	
		
		
		// Setting Labels for Overview tab
		m_VetNameLabel = new Label();
		m_PetNameLabel = new Label();
		m_PetSpeciesLabel = new Label();
		m_PetGenderLabel = new Label();
		m_ProcedureAmountLabel = new Label();
		m_ProcedureAmountCoveredLabel = new Label();
		m_ProcedureAmountDueLabel = new Label();
		// Setting Text for Labels on Overview tab
		m_VetNameLabel.setText("Veterinarian Name:");
		m_PetNameLabel.setText("Pet Name:");
		m_PetSpeciesLabel.setText("Pet Species:");
		m_PetGenderLabel.setText("Pet Gender:");
		m_ProcedureAmountLabel.setText("Procedure Amount:");
		m_ProcedureAmountCoveredLabel.setText("Procedure Amount Covered:");
		m_ProcedureAmountDueLabel.setText("Procedure Amount Due:");
		//ADDING Overview tab labels to Overview Label vbox which go into the left side of border pane which goes to the scene. EZ
		VBox overviewLabelVBox = new VBox();
		border.setLeft(overviewLabelVBox);
		overviewLabelVBox.setSpacing(25);
		overviewLabelVBox.getChildren().add(m_VetNameLabel);
		overviewLabelVBox.getChildren().add(m_PetNameLabel);
		overviewLabelVBox.getChildren().add(m_PetSpeciesLabel);
		overviewLabelVBox.getChildren().add(m_PetGenderLabel);
		overviewLabelVBox.getChildren().add(m_ProcedureAmountLabel);
		overviewLabelVBox.getChildren().add(m_ProcedureAmountCoveredLabel);
		overviewLabelVBox.getChildren().add(m_ProcedureAmountDueLabel);
		//Setting the textAreas for right side of overview tab
		m_VetNameTextArea = new TextArea();
		m_PetNameTextArea = new TextArea();
		m_PetSpeciesTextArea = new TextArea();
		m_PetGenderTextArea = new TextArea();
		m_TotalProcedureAmountTextArea = new TextArea();
		m_TotalProcedureAmountCoveredTextArea = new TextArea();
		m_TotalProcedureAmountDueTextArea = new TextArea();
		//Setting the text boxes with the data
		
		VBox overviewTextAreaVBox = new VBox();
    	overviewTextAreaVBox.setSpacing(3);
    	m_VetNameTextArea.setText(Visit.getVeterinarian());
    	m_VetNameTextArea.setMaxHeight(5);
    	m_VetNameTextArea.setMaxWidth(200);
    	m_PetNameTextArea.setText(Visit.getPetName());
    	m_PetNameTextArea.setMaxHeight(5);
    	m_PetNameTextArea.setMaxWidth(200);
    	m_PetSpeciesTextArea.setText(Visit.getPetSpecies());
    	m_PetSpeciesTextArea.setMaxHeight(5);
    	m_PetSpeciesTextArea.setMaxWidth(200);
    	m_PetGenderTextArea.setText(Visit.getPetGender());
    	m_PetGenderTextArea.setMaxHeight(5);
    	m_PetGenderTextArea.setMaxWidth(200);
    	m_TotalProcedureAmountTextArea.setText(Visit.getProcedureAmount());
    	m_TotalProcedureAmountTextArea.setMaxHeight(5);
    	m_TotalProcedureAmountTextArea.setMaxWidth(200);
    	m_TotalProcedureAmountCoveredTextArea.setText(Visit.getProcedureAmountCovered());
    	m_TotalProcedureAmountCoveredTextArea.setMaxHeight(5);
    	m_TotalProcedureAmountCoveredTextArea.setMaxWidth(200);
    	m_TotalProcedureAmountDueTextArea.setText(Visit.getProcedureAmountDue());
    	m_TotalProcedureAmountDueTextArea.setMaxHeight(5);
    	m_TotalProcedureAmountDueTextArea.setMaxWidth(200);
    	
    	// Adding the TextAreas to the VBOX which is on the right side of the pane
    	overviewTextAreaVBox.getChildren().add(m_VetNameTextArea);
    	overviewTextAreaVBox.getChildren().add(m_PetNameTextArea);
    	overviewTextAreaVBox.getChildren().add(m_PetSpeciesTextArea);
    	overviewTextAreaVBox.getChildren().add(m_PetGenderTextArea);
    	overviewTextAreaVBox.getChildren().add(m_TotalProcedureAmountTextArea);
    	overviewTextAreaVBox.getChildren().add(m_TotalProcedureAmountCoveredTextArea);
    	overviewTextAreaVBox.getChildren().add(m_TotalProcedureAmountDueTextArea);
		border.setRight(overviewTextAreaVBox);
		
		// CREATING A LIST VIEW
		ListView<VisitProcedure> list = new ListView<VisitProcedure>();
		
		ObservableList<VisitProcedure> visits = FXCollections.observableArrayList(Visit.getVisitProcedures());
		
		list.setItems(visits);
		VBox contentVBox = new VBox();
		contentVBox.getChildren().add(list);
		visitProcedureDataTab.setContent(contentVBox);
		
		
		
/**
 *  Event Handler for Open
 *  @since 12/12/2018
 *  @author Jupraj Singh
 */
		open.setOnAction( new EventHandler<ActionEvent>() {
		      public void handle(ActionEvent t) {
		    	  FileChooser fileChooser = new FileChooser();
		 		 fileChooser.setTitle("Select File to Read from");
		 		 fileChooser.getExtensionFilters().addAll(
		 		         new ExtensionFilter("Text Files", "*.txt"),
		 		         new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
		 		         new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
		 		         new ExtensionFilter("All Files", "*.*"));
		 		 File selectedFile = fileChooser.showOpenDialog(primaryStage);
		 		 Scanner s;
		 		try {
		 			s = new Scanner(new FileReader(selectedFile));
		 			Visit.Read(s);
		 			// changing the GUI data after reading from the file
		 			m_VetNameTextArea.setText(Visit.getVeterinarian());
		 	    	m_PetNameTextArea.setText(Visit.getPetName());
		 	    	m_PetSpeciesTextArea.setText(Visit.getPetSpecies());
		 	    	m_PetGenderTextArea.setText(Visit.getPetGender());
		 	    	m_TotalProcedureAmountTextArea.setText(Visit.getProcedureAmount());
		 	    	m_TotalProcedureAmountCoveredTextArea.setText(Visit.getProcedureAmountCovered());
		 	    	m_TotalProcedureAmountDueTextArea.setText(Visit.getProcedureAmountDue());
		 	    	// INSERT LISTS HERE
		 	    	visits.clear();
		 	    	ObservableList<VisitProcedure> visits = FXCollections.observableArrayList(Visit.getVisitProcedures());
		 	    	list.setItems(visits);
		 	    	
		 		} catch (FileNotFoundException e) {
		 			
		 			e.printStackTrace();
		 		
		 		}
		 		 
		 		 if (selectedFile != null) {
		 			
		 		 }
		      }
		   }
		);
/**
 *  Event Handler For Save As...
 *  Should display a filechooser and let the user
 *  decide which file to write data to
 *  the program should write data from the visit instance
     into the file
 *  
 *  @since 12/12/2018
 *  @author Jupraj Singh
 */
		
		saveAs.setOnAction( new EventHandler<ActionEvent>() {
		      public void handle(ActionEvent t) {
		    	  FileChooser fileChooser = new FileChooser();
			 		 fileChooser.setTitle("Save As Visit");
			 		 fileChooser.getExtensionFilters().addAll(
			 		         new ExtensionFilter("Text Files", "*.txt"),
			 		         new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
			 		         new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
			 		         new ExtensionFilter("All Files", "*.*"));
			 		 File selectedFile = fileChooser.showOpenDialog(primaryStage);
		           PrintStream ps = null;
		           try {
					ps = new PrintStream(selectedFile);
					Visit.Write(ps);
				} catch (FileNotFoundException e) {

					e.printStackTrace();
				}
		      }
		   }
		);
/**
 *  Event Handler for Save Report...
 *  Allows users to select a file and then saves the data in report format on that file
 *  @since 12/12/2018
 *  @author Jupraj Singh
 */
		saveReport.setOnAction( new EventHandler<ActionEvent>() {
		      public void handle(ActionEvent t) {
		    	  FileChooser fileChooser = new FileChooser();
			 		 fileChooser.setTitle("Save Visit Report");
			 		 fileChooser.getExtensionFilters().addAll(
			 		         new ExtensionFilter("Text Files", "*.txt"),
			 		         new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
			 		         new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
			 		         new ExtensionFilter("All Files", "*.*"));
			 		 File selectedFile = fileChooser.showOpenDialog(primaryStage);
		           PrintStream ps = null;
		           try {
					ps = new PrintStream(selectedFile);
					Visit.Report(ps);
				} catch (FileNotFoundException e) {

					e.printStackTrace();
				}
		      }
		   }
		);
/**
 * Event Handler for Export as JSON
 * User selects file and the JSON string will be printed on selected file
 * @author Jupraj Singh
 * @since 12/12/2018
 */
		exportAsJSON.setOnAction( new EventHandler<ActionEvent>() {
		      public void handle(ActionEvent t) {
		    	  FileChooser fileChooser = new FileChooser();
			 		 fileChooser.setTitle("Export As JSON");
			 		 fileChooser.getExtensionFilters().addAll(
			 		         new ExtensionFilter("Text Files", "*.txt"),
			 		         new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
			 		         new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
			 		         new ExtensionFilter("All Files", "*.*"));
			 		 File selectedFile = fileChooser.showOpenDialog(primaryStage);
		           PrintStream ps = null;
		           try {
					ps = new PrintStream(selectedFile);
					String myJSON = Visit.GetJSON();
					ps.print(myJSON);
				} catch (FileNotFoundException e) {

					e.printStackTrace();
				}
		      }
		   }
		);
/**
 * Event Handler for Exit
 * Will exit the GUI
 * @author Jupraj Singh
 * @since 12/12/2018
 */
		exit.setOnAction( new EventHandler<ActionEvent>() {
		      public void handle(ActionEvent t) {
		            primaryStage.close();
		      }
		   }
		);

		
		
		
		// overarching VBox that will hold the menu items, 
		//the tabs, and the pane inside the overview tab
		// in other words, the ultimate VBox
		VBox ultimateVBox = new VBox();
		ultimateVBox.getChildren().add(menuBar);
		ultimateVBox.getChildren().add(tabPane);


		//Creating a Scene, no pun intended
		overviewTab.setClosable(false);
		visitProcedureDataTab.setClosable(false);
		overviewTab.setContent(border);
		tabPane.getTabs().add(overviewTab);
		tabPane.getTabs().add(visitProcedureDataTab);
		
		//Scene scene = new Scene(tabPane,500,500);
		Scene scene = new Scene(ultimateVBox,500,500);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
}
