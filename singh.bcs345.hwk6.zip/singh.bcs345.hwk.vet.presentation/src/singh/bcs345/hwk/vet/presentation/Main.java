package singh.bcs345.hwk.vet.presentation;
import java.io.FileReader;

import java.io.PrintStream;
import java.util.Scanner;

import singh.bcs345.hwk.vet.business.*;

/*
 * so, when i went to save the business file, it couldn't find the file and somehow the only thing that remained was
 * Main, so i lost all of my classes
 * I managed to find an old save and had to copy and paste all my old classes back
 * not sure if this will impact how you are able to run the code, so I thought it would be useful to leave this comment
 * 
 * Write. Should write out the number of VisitProcedures to the output file 
 * just before writing the VisitProcedure data. The file that is generated should use the format 
 * detailed in the homework specifications. 
 * FIXED


GetJSON. There should not be a comma after the last VisitProcedure of the array. 
Fixed, I believe the string is in JSON format


GetByIndex. An index value of 0 should be allowed (not throw an exception) since it is a valid index. 
Test should be the following:
if (index >= 0 && index <= VisitProcedure.length-1)
FIXED

GetHighestProcedureAmountDue. Should not call new for each array element.
 All the data that was in the array before the call to GetHighestProcedureAmountDue is lost.
 FIXED


ShowUI. Should redisplay the menu after processing the user's choice. The menu will quickly move 
off screen and the user will be forced to scroll back and forth if they want to read it. 
FIXED

ShowUI. Choice 5. Should write the report to the screen (not a file). 
You can pass Report a PrintStream that is connected to System.out and it will print the report on the screen. 
Prints to screen, a little offcenter, formatting is off
 */



/**
 * This is the main method. 
 * This will call the showUI method
 * 
 * @author Jupraj Singh
 *@version 1.00
 *@since 10/3/2018
 */

import javafx.application.Application;

/**
 * The main class which will allow users to choose between
 * VisitProcedureConsoleUI, 
 * VisitConsoleUI,
 * and the VetGraphicalUI
 * @author Jupraj Singh
 * @since 12/12/2018
 *
 */
public class Main {
	public static void main(String args[])
	{
		


		
		System.out.println("Choose UI");
		System.out.println("---------");
		int choiceMain;
		Scanner s = new Scanner(System.in);		
		do {
			System.out.println("1 - VisitProcedureConsoleUI");
			System.out.println("2 - VisitConsoleUI");
			System.out.println("3 - VetGraphicalUI");
			System.out.println("4 - Exit");
			System.out.println("Enter choice:");
		choiceMain = s.nextInt();
		switch (choiceMain)
		{
		case 1: 
			VisitProcedureConsoleUI ui= new VisitProcedureConsoleUI();
			ui.ShowUI();
			break;
		case 2:
			VisitConsoleUI DaConsole= new VisitConsoleUI();
			DaConsole.ShowUI();
			break;
		case 3:
			VetGraphicalUI hi = new VetGraphicalUI();
			hi.ShowUI();
			break;
		case 4:
			System.out.println("Program is now closing..");
			break;
		default:
			System.out.println("Invalid choice, please enter again:");
			break;
		} 
		}while (choiceMain != 4);
	
	}
}

		
		/*
		// making a new pet, p
		Pet p = new Pet();
		// testing Pet Name getter/setter
		String testPetName = "Joops";
		p.setName("Joops");
		
		if (testPetName.equals(p.getName()))
		{
			System.out.println("Pet Get/Set Name: Pass");
		}
		else
		{
			System.out.println("Pet Get/Set Name: Fail");
		}
			
		// testing Pet Species getter/setter	
		String testPetSpecies = "Cat";
		p.setSpecies("Cat");
		
		if (testPetSpecies.equals(p.getSpecies()))
		{
			System.out.println("Pet Get/Set Species: Pass");
		}
		else
		{
			System.out.println("Pet Get/Set Species: Fail");
		}
			
		// testing Pet Gender getter/setter	
		String testPetGender = "Female";
		p.setGender("Female");
				
		if (testPetGender.equals(p.getGender()))
		{
			System.out.println("Pet Get/Set Gender: Pass");
		}
		else
		{
			System.out.println("Pet Get/Set Gender: Fail");
		}

		// creating new procedure called m
		Procedure m= new Procedure();
		// testing procedure Name Getter/setter
		String testProcedureName = "Shots";
		m.setName("Shots");
		if (testProcedureName.equals(m.getName()))
		{
			System.out.println("Procedure Get/Set Name: Pass");
		}
		else
		{
			System.out.println("Procedure Get/Set Name: Fail");
		}
		
		// testing procedure Price Getter/setter
		double testProcedurePrice = 10.44;
		m.setPrice(10.44);
		if (testProcedurePrice == (m.getPrice()))
		{
			System.out.println("Procedure Get/Set Price: Pass");
		}
		else
		{
			System.out.println("Procedure Get/Set Price: Fail");
		}
		
		// testing pet constructors
		Pet x = new Pet();
		String defaultN = "Default Name";
		String defaultS = "Dog";
		String defaultG = "Male";
		if (defaultN.equals(x.getName()) && defaultS.equals(x.getSpecies()) && defaultG.equals(x.getGender()))
		{
			System.out.println("Default Constructor for Pet:Pass");
		}
		else
		{
			System.out.println("Default Constructor for Pet: Fail");
		}
		
		Pet y = new Pet("Bugs","Bunny","Male");
		defaultN = "Bugs";
		defaultS = "Bunny";
		defaultG = "Male";
		if (defaultN.equals(y.getName()) && defaultS.equals(y.getSpecies()) && defaultG.equals(y.getGender()))
		{
			System.out.println("Two parameter Constructor for Pet:Pass");
		}
		else
		{
			System.out.println("Two parameter Constructor for Pet: Fail");
		}
		
		// testing procedure constructors
		
		Procedure a = new Procedure();
		defaultN = "Default";
		double defaultP = 0.00;
		if (defaultN.equals(a.getName()) && defaultP == a.getPrice())
		{
			System.out.println("Default Constructor for Procedure:Pass");
		}
		else
		{
			System.out.println("Default Constructor for Procedure: Fail");
		}
		
		Procedure b = new Procedure("Rabies", 20.00);
		defaultN = "Rabies";
		defaultP = 20.00;
		if (defaultN.equals(b.getName()) && defaultP == b.getPrice())
		{
			System.out.println("Double parameter Constructor for Procedure:Pass");
		}
		else
		{
			System.out.println("Double parameter Constructor for Procedure: Fail");
		}
		
		// testing write function for pets
		PrintStream pets = null;
		try
		{
			pets = new PrintStream("petOutput.txt");
		}
		catch (Exception e)
		{
			System.out.println("ERROR in opening file");
		}
		
		// prints the data of pet1 to petOutput.txt
		Pet pet1 = new Pet("Clifford", "Dog", "Male");
		pet1.Write(pets);
		
		String Cliff = "Clifford";
		String doggy = "Dog";
		String gen = "Male";
		if (pet1.getName().equals(Cliff) && pet1.getSpecies().equals(doggy) && pet1.getGender().equals(gen))
		{
			System.out.println("The write function for pets: Pass");
		}
		else
		{
			System.out.println("The write function for pets: Fail");
		}
		
		// testing write function for Procedures
			PrintStream proc = null;
			try
			{
				proc = new PrintStream("procedureOutput.txt");
				
			}
			catch (Exception e)
			{
					System.out.println("ERROR in opening file");
			}
			// prints the data of proc1 to procedureOutput.txt
			Procedure proc1 = new Procedure("Flu", 12.35);
			proc1.Write(proc);
			String flee = "Flu";
			double fee = 12.35;
			if (proc1.getName().equals(flee) && proc1.getPrice() == fee)
			{
				System.out.println("The write function for procedures: Pass");
			}
			else
			{
				System.out.println("The write function for procedures: Fail");
			}
			
			
		//Testing read function for pets
		Scanner inputScanner = null;
		FileReader fr = null;
		try
		{
			fr = new FileReader("Pet.txt");
			inputScanner = new Scanner(fr);
		}
		catch (Exception e)
		{
			System.out.println("Error in opening pet.txt");
		}
		// Reading the data of pet2 in Pet.txt
		Pet pet2 = new Pet();
		pet2.Read(inputScanner);
		String testName = "Buster";
		String testSpecies = "Rabbit";
		String testGender = "Male";
	
		if(pet2.getName().equals(testName) && pet2.getSpecies().equals(testSpecies) && pet2.getGender().equals(testGender))
		{
			System.out.println("The Read function for pets: Pass");
		}
		else
		{
			System.out.println("The Read function for pets: Fail");
		}
		
		// testing Read for Procedures
				Scanner inputProc = null;
				FileReader pr = null;
				try
				{
					pr = new FileReader("Procedure.txt");
					inputProc = new Scanner(pr);
				}
				catch (Exception e)
				{
					System.out.println("Error in opening Procedure.txt");
				}
				// reads the data of proc2 from the procedure.txt
				Procedure proc2 = new Procedure();
				proc2.Read(inputProc);
				String procName = "Rabies Shot";
				double procPrice = 25.60;
				
				if(proc2.getName().equals(procName) && proc2.getPrice() == procPrice)
				{
					System.out.println("The read function for procedures: Pass");
				}
				else
				{
					System.out.println("The read function for procedures: Fail");
				}
					
				// testing getJSON for pets
				String jsonName = "Jupraj";
				String jsonSpecies="Human";
				String jsonGender = "Male";
				String testJ = "{" + "\"Name\""+ ":" + jsonName + "," + "\"Species\"" + ":" + jsonSpecies + ":" + "\"Gender\"" + ":" + jsonGender + "}";
				
				Pet joops = new Pet("Jupraj","Human","Male");
			
				if(joops.GetJSON().equals(testJ))
				{
					System.out.println("JSON function for Pets: Pass");
				}
				else
				{
					System.out.println("JSON function for Pets: Fail");
				}
						
				// testing getJSON for Procedures
				jsonName = "Chicken Pox";
				double jsonPrice = 10.00;
				String testP = "{" + "\"Name\""+ ":" + jsonName + "," + "\"Price\"" + ":" + jsonPrice;
				
				Procedure Pox = new Procedure("Chicken Pox", 10.00);
				if (Pox.GetJSON().equals(testP))
				{
					System.out.println("JSON function for Procedures: Pass");
				}
		
				else
				{
					System.out.println("JSON function for Procedures: Fail");
				}
		
		// Testing toString for Pets
			String testPetString = "Name:Goofy\nSpecies:Dog\nGender:Male";
			Pet Goofy = new Pet("Goofy","Dog","Male");
			
			if (Goofy.toString().equals(testPetString))
			{
				System.out.println("toString function for pets: Pass");
			}
			else
			{
				System.out.println("toString function for pets: Fail");
			}
		
			
		// Testing toString for Procedures
			String V = "Vaccination";
			double pric = 2.00;
			String testProcString = "Name:" + V + "\nPrice:$" + pric;
			Procedure Vac = new Procedure("Vaccination",2.00);
			if (Vac.toString().equals(testProcString))
			{
				System.out.println("toString function for procedures: Pass");
			}
			else
			{
				System.out.println("toString function for procedures: Fail");
			}
			
	}

	}
}
*/
