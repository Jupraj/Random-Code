package singh.bcs345.hwk.vet.business;

import java.io.PrintStream;
import java.util.Scanner;
/**
 * This class contains the Visit Procedure
 * which contains the Procedure, Quantity, IsCoveredByInsurance, PctCovered
 * read and write functions,
 * getJSON and toString methods
 * @author Jupraj Singh
 * @since 10-25-2018
 *
 */
public class VisitProcedure {
	// member variables
	private Procedure Procedure;
	protected double Quantity;
	private boolean IsCoveredByInsurance;
	private Double PctCovered;
	/**
	 * default constructor for visitProcedure. Will assign default values to the member variables
	 */
	public VisitProcedure()
	{
		Procedure= new Procedure();
		Quantity = 1.00;
		IsCoveredByInsurance = true;
		PctCovered = 0.10;
	}
	/**
	 * Getter functions which will return a member variable
	 * @author Jupraj Singh
	 */
	public Procedure getProcedure()
	{
		return Procedure;
	}
	public double getQuantity()
	{
		return Quantity;
	}
	public boolean getIsCoveredByInsurance()
	{
		return IsCoveredByInsurance;
	}
	public double getPctCovered()
	{
		return PctCovered;
	}
	/**
	 * Setter functions that you can use to assign member variables
	 * @param p
	 * @author Jupraj Singh
	 */
	public void setProcedure(Procedure p)
	{
		Procedure = p;
	}
	public void setQuantity(double q)
	{
		Quantity = q;
	}
	public void setIsCoveredByInsurance(boolean b)
	{
		IsCoveredByInsurance = b;
	}
	public void setPctCovered(double p)
	{
		PctCovered = p;
	}
	/**
	 *  Returns the procedure amount. Price times the quantity
	 * @return
	 */
	public double CalculateProcedureAmount()
	{
		return Procedure.getPrice() * Quantity;
	}
	/**
	 *  Returns the procedure that is covered by insurance. 
	 * @return
	 */
	public double CalculateProcedureAmountCovered()
	{
		if (IsCoveredByInsurance == false)
		{
			return 0.00;
		}
		else
		return Procedure.getPrice() * PctCovered;
	}
	/**
	 * returns the amount the customer actually has to pay
	 * @return
	 */
	public double CalculateProcedureAmoutDue()
	{
		if (IsCoveredByInsurance == true)
		{
			return Procedure.getPrice() * Quantity - CalculateProcedureAmountCovered();
		}
		else
		return Procedure.getPrice() * Quantity;
	}
	/**
	 *  Write the contents of all member variables to the given printstream.
	 * @param ps passes a printstream to the function
	 */
	public void Write(PrintStream ps)
	{
		ps.printf("%s\n%f\n%f\n%b\n%f", Procedure.getName(), Procedure.getPrice(),Quantity,IsCoveredByInsurance,PctCovered);
	}
	// Reads the content of all member variables from a given Scanner
	public void Read(Scanner s)
	{
		if(s.hasNextLine()== true)
		{
		Procedure = new Procedure(s.nextLine(), s.nextDouble());
		Quantity = s.nextDouble();
		IsCoveredByInsurance = s.nextBoolean();
		PctCovered = s.nextDouble();
		}
	}
	/**
	 *  Returns a string using JSON formating
	 * @return
	 */
	public String getJSON()
	{
		return "{" + "\n\t\"Procedure\" : " + "\n\t{\n" + "\t\t\"Name\" : \""
		+ Procedure.getName() + "\"" +  ",\n" + "\t\t\"price\" : " + Procedure.getPrice()
		+ "\n\t} ," + "\n\t\"quantity\" : " + Quantity + "," + "\n\t\"IsCoveredByInsurance\" : " 
		+ IsCoveredByInsurance + "," + "\n\t\"PctCovered\" : " + PctCovered + "\n\t}\n";
	}
	/**
	 *  returns a string that contains the values of the member variables with descriptive text
	 *  @author Jupraj Singh
	 */
	@Override
	public String toString()
	{
		return "Name: " + Procedure.getName() + "\nPrice: " 
		+ Procedure.getPrice() + "\nQuantity: " + Quantity
		+ "\nIs Covered By Insurance: " + IsCoveredByInsurance
		+ "\nPct Covered: " + PctCovered;
	}
}
