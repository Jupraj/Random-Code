package singh.bcs345.hwk.vet.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * This is the Procedure class
 * Contains the Name and Price variables
 * Getters/Setters
 * Default constructor and a constructor with two parameters
 * A Write and Read function
 * A JSON formatting function and a toString formatting function
 * @author Jupraj Singh
 * @version 1.00
 * @since 10/3/2018
 *
 */
public class Procedure {
	// member variables
	private String Name;
	private double Price;
	//default constructor
	public Procedure()
	{
		Name = "Default";
		Price = 10.00;
	}
	// constructor that takes two parameters
	public Procedure(String N, double P)
	{
		Name = N;
		Price = P;
	}
	// Getters
	public String getName()
	{
		return Name;
	}
	public double getPrice()
	{
		return Price;
	}
	//Setters
	public void setName(String n)
	{
		Name = n;
	}
	public void setPrice(double P)
	{
		Price = P;
	}
	//write data to a file
	public void Write(PrintStream ps)
	{
		ps.printf("%s\n%.2f\n", Name, Price);
	}
	//read data from a scanner
	public void Read(Scanner s)
	{
		Name = s.nextLine();
		Price = s.nextDouble();
	}
	//returns a string in JSON formatting
	public String GetJSON()
	{
		return "{" + "\"Name\""+ ":" + Name + "," + "\"Price\"" + ":" + Price;
	}
	// returns a string of the member variables with descriptive text
	@Override
	public String toString()
	{
		return "Name:" + Name + "\nPrice:$" + Price;
	}
	
	
}
