package singh.bcs345.hwk.vet.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Visit Class which contains the member variables
 * Veterinarian, Appointment and a VisitProcedure array
 * Contains default Constructor, get/set for Veterinarian,
 * Read,Write,Report,getJSON,toString,GetByIndex,
 * and GetHighestProcedureAmountDue functions
 * 
 * UPDATE 12/12/2018 
 * Now includes functions such as get pet name,gender,species
 * procedure amount, amountCovered, and amountdue
 * in order to help with GUI functionality
 * 
 * @since 11/14/2018
 * @author Jupraj Singh
 *
 */
public class Visit {
	private String Veterinarian;
	private Appointment Appointment;
	private VisitProcedure VisitProcedure[];
	private int num;
	
	/**
	 * Default Constructor for visit class
	 * sets default values for member variables
	 * Veterinarian, appointment and A VisitProcedure array of 4 elements
	 * @since 11/14/2018
	 * @author Jupraj Singh
	 */
	public Visit()
	{
		this.Veterinarian = "Andrea Rodriguez";
		this.Appointment = new Appointment();
		this.VisitProcedure = new VisitProcedure[4];
		
		for (int i=0;i<VisitProcedure.length;i++)
		{
			VisitProcedure[i] = new VisitProcedure();
		}
	}
	/**
	 * Getter function for Veterinarian member variable
	 * @since 11/14/2018
	 * @author Jupraj Singh
	 */
	public String getVeterinarian() 
	{
		return Veterinarian;
	}
	/**
	 * This function will return the petname, helps with the GUI
	 * @since 12/12/2018
	 * @author Jupraj Singh
	 */
	public String getPetName()
	{
		return Appointment.getPet().getName();
	}
	/**
	 * This function will return the petSpecies, helps with the GUI
	 * @since 12/12/2018
	 * @author Jupraj Singh
	 */
	public String getPetSpecies()
	{
		return Appointment.getPet().getSpecies();
	}
	/**
	 * This function will return the petGender, helps with the GUI
	 * @since 12/12/2018
	 * @author Jupraj Singh
	 */
	public String getPetGender()
	{
		return Appointment.getPet().getGender();
	}
	/**
	 * This function will return the ProcedureAmount in string form, helps with the GUI
	 * @since 12/12/2018
	 * @author Jupraj Singh
	 */
	public String getProcedureAmount()
	{
		String S= "";
		double total = 0;
		for(int i =0 ; i< VisitProcedure.length;i++) {
		total += VisitProcedure[i].CalculateProcedureAmount();
		}
		return S + total;
	}
	/**
	 * This function will return the ProcedureAmountCovered in string form, helps with the GUI
	 * @since 12/12/2018
	 * @author Jupraj Singh
	 */
	public String getProcedureAmountCovered()
	{
		double total = 0;
		String S= "";
		for(int i =0 ; i< VisitProcedure.length;i++) {
			total += VisitProcedure[i].CalculateProcedureAmountCovered();
		}
		return S + total;
	}
	/**
	 * This function will return the ProcedureAmountDue in string form, helps with the GUI
	 * @since 12/12/2018
	 * @author Jupraj Singh
	 */
	public String getProcedureAmountDue()
	{
		String S= "";
		double total = 0;
		for(int i =0 ; i< VisitProcedure.length;i++) {
		total += VisitProcedure[i].CalculateProcedureAmoutDue();
		}
		return S + total;
	}
	/**
	 * Setter function for Veterinarian member variable
	 * @since 11/14/2018
	 * @author Jupraj Singh
	 */
	public void setVeterinarian(String n)
	{
		Veterinarian = n;
	}
	/**
	 * A read function that reads the contents of all member variables
	 * from a given instance of Scanner
	 * @since 11/14/2018
	 * @author Jupraj Singh
	 */
	public void Read(Scanner s)
	{
		Veterinarian = s.nextLine();
		Appointment.Read(s);


		num = s.nextInt();
		s.nextLine();
		
		for (int i = 0;i<num;i++)
		{
			VisitProcedure[i].Read(s);
			if(s.hasNextLine() == true)
			{
				s.nextLine();
			}
		}
		

		
	}
	/**
	 * A write function that writes the contents
	 * of all member variables to a given instance
	 * of Print Stream
	 * @since 11/14/2018
	 * @author Jupraj Singh
	 */
	public void Write(PrintStream ps)
	{
		ps.printf("%s\n",Veterinarian);
		Appointment.Write(ps);
		ps.println(num);
		for (int i=0;i<VisitProcedure.length;i++)
		{
			VisitProcedure[i].Write(ps);
			ps.println("");
		}
	}
	/** 
	 * Report function
	 * Writes a report of the visit
	 * using a PrintStream
	 * Updated to look good on the file selected in the GUI
	 * @since 12/12/2018
	 * @author Jupraj Singh
	 */
	public void Report(PrintStream ps)
	{
		ps.println("Pet Veterinarian Visit Report");
		ps.println("------------------------------");
		ps.printf("Veterinarian: %s", Veterinarian);
		ps.printf("\nDate        : %d/%d/%d", Appointment.Month, Appointment.Day, Appointment.Year);
		ps.printf("\n\nPet Name   : %s", Appointment.getPet().getName());
		ps.printf("\nPet Species: %s", Appointment.getPet().getSpecies());
		ps.printf("\nPet Gender : %s", Appointment.getPet().getGender());
		ps.println("\n\nProcedures");
		ps.printf("Name\t\t\t\t\t\t\tPrice \tQty\tAmount\t\tIs Covered\tPct Covered\tAmount Covered\tAmount Due");
		ps.printf("\n----\t\t\t\t\t\t   ------\t--- --------\t----------\t-----------\t---------------\t----------------\n");
		double totalAmount = 0.00;
		double totalCovered = 0.00;
		double totalDue = 0.00;
		for(int i=0; i< VisitProcedure.length;i++)
		{
			double amount = VisitProcedure[i].getProcedure().getPrice() * VisitProcedure[i].getQuantity();
			double amountCovered = amount * VisitProcedure[i].getPctCovered();
			double amountDue = amount - amountCovered;
			ps.printf("%-25s", VisitProcedure[i].getProcedure().getName());
			ps.printf("\t%9.2f", VisitProcedure[i].getProcedure().getPrice());
			ps.printf("%5.0f", VisitProcedure[i].getQuantity());
			ps.printf("%8.2f", VisitProcedure[i].CalculateProcedureAmount());
			ps.printf("%11s", VisitProcedure[i].getIsCoveredByInsurance());
			ps.printf("%17.2f", VisitProcedure[i].getPctCovered());
			ps.printf("%13.2f",VisitProcedure[i].CalculateProcedureAmountCovered());
			ps.printf("%13.2f\n",VisitProcedure[i].CalculateProcedureAmoutDue());
			totalAmount += VisitProcedure[i].CalculateProcedureAmount();
			totalCovered += VisitProcedure[i].CalculateProcedureAmountCovered();
			totalDue += VisitProcedure[i].CalculateProcedureAmoutDue();
		}
		ps.printf("----\t\t\t\t\t\t    ------  --- --------\t----------\t-------------- -----\t----------\n");
		ps.printf("Total");
		// This is where the total amount values are displayed
		ps.printf("\t\t\t\t\t\t\t\t%18.2f", totalAmount);
		ps.printf("\t\t\t\t\t%25.2f", totalCovered);
		ps.printf("\t%12.2f", totalDue);
		
		
	}
	/**
	 * GetJSON
	 * Returns a string using JSON formatting
	 */
	public String GetJSON()
	{
		String S= "";
		S += "{\n";
		S += "\" Veterinarian Name\" : \"" + Veterinarian + "\"\n";
		S += "\"Appointment\"  :\n";
		S += Appointment.GetJSON();
		S += "\n\"visitProcedure\"  :\n";
		S += "[\n";
		
		for(int i = 0; i < VisitProcedure.length; i++)
		{
			S += VisitProcedure[0].getJSON();
			if (i<VisitProcedure.length - 1)
			{
				S += ",";
			}
		}
		
		 
		S += "\n   ]\n";
		S += "}";
		return S;
	}
	/**
	 * To String method
	 * shows descriptive text and data of all the member variables
	 */
	@Override
	public String toString()
	{
		String S;
		S = "Veterinarian: " + Veterinarian  + "\n"
				+ Appointment.toString() 
				+ "\n";
				for (int i = 0; i < VisitProcedure.length;i++)
				{
					S += VisitProcedure[i].toString();
					S += "\n";
				}
		return S;
	}
	/**
	 * GetByIndex function
	 * returns the VisitProcedure instance at the given index
	 * should THROW an arrayIndexOutofBounds exception
	 * if the index is invalid
	 */
	 public Procedure GetByIndex(int index) throws ArrayIndexOutOfBoundsException
	 {
		 Procedure p;
		 if (index >= 0 && index <= VisitProcedure.length-1)
		 {
			 p = VisitProcedure[index].getProcedure();
			 return p;
		 }
		 else
		 {
			 ArrayIndexOutOfBoundsException e;
			 e = new ArrayIndexOutOfBoundsException();
			 throw e;
		 }
		
	 }
	/**
	 * GetHighestProcedureAmountDue function
	 * searches the array of VisitProcedure 
	 * for the instance with the highest amount due
	 * and returns it from the method
	 * Amount due = price of procedure times the quantity
	 * with the amount covered by insurance substracted from it
	 * Only take insurance into account if the IsCovered memeber is true
	 */
	public VisitProcedure GetHighestProcedureAmountDue()
	{
		VisitProcedure highest= VisitProcedure[0];
		double AmountDue=0 ;
		for(int i=0;i<VisitProcedure.length;i++)
		{
			VisitProcedure[i].CalculateProcedureAmoutDue();
			if(AmountDue < VisitProcedure[i].CalculateProcedureAmoutDue())
			{
				AmountDue = VisitProcedure[i].CalculateProcedureAmoutDue();
				highest = VisitProcedure[i];
			}
		}
		return highest;
		
	}
	
	public VisitProcedure[] getVisitProcedures()
	{
		return this.VisitProcedure;
		
	}
}

